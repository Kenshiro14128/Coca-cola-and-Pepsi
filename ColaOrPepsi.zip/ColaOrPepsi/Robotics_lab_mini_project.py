# Libaries
import cv2
from ultralytics.yolo.engine.model import YOLO

# Import model
model = YOLO('best.pt')

# Run model and run camera
results = model.predict(source='0', show=True, conf=0.5)
